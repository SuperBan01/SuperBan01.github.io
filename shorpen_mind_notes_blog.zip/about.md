
---
layout: post
title: "关于我"
---

你好，我是 **Shorpen**。  
我在这里记录思考、写作与梦蝶心智模型的成长过程。
