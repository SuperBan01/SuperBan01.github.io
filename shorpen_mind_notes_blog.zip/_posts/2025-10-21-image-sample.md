
---
layout: post
title: "图像记忆"
---

有时候，一张图能承载一整个时刻的意识。

![](../assets/images/sample1.jpg)
